describe('webdriver.io page', () => {



    it('shadow Dom extractor', async () => {
        await browser.url('http://localhost:4200')
        const title = browser.getTitle()

       const parentElement = await $('#shadow-exp');
       console.log('parentElement found :', parentElement);
       // browser.debug();

       const shadow = await parentElement.shadow$('h1');
       console.log('shadow contains : ', shadow);
       let shadowText = await shadow.getText();
        console.log('shadow text : ', shadowText);

        // expect(browser).toHaveTitle('WebdriverIO · Next-gen browser and mobile automation test framework for Node.js');
    })
})
